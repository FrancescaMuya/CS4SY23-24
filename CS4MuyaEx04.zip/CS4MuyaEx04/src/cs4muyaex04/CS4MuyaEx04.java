
package cs4muyaex04;

import java.util.Scanner;

/**
 *
 * @author Francesca Muya
 */
public class CS4MuyaEx04 {

    public static void main(String[] args) {
        Move rock = new Move("Rock");
        Move paper = new Move("Paper");
        Move scissors = new Move("Scissors");
        
        rock.setStrongAgainst(scissors);
        paper.setStrongAgainst(rock);
        scissors.setStrongAgainst(paper);
        
        int roundsToWin = 2;
        int playerScore = 0;
        int computerScore = 0;
        boolean donePlaying = true;
        
        Scanner scan = new Scanner(System.in);
        
        while(donePlaying) {
            System.out.println("\nWelcome to Rock, Paper, Scissors. Please choose an option:" 
                    + "\n 1. Start game" 
                    + "\n 2. Change number of rounds" 
                    + "\n 3. Exit application \n >");
                    
            int choice = scan.nextInt();
            
            switch(choice) {
                case 1: 
                    System.out.println("This match will be first to " + roundsToWin + " wins.");
                    
                    while(playerScore < roundsToWin && computerScore < roundsToWin) {
                        System.out.println("The computer has selected its move. Select your move:"
                                + "\n 1. Rock"
                                + "\n 2. Paper"
                                + "\n 3. Scissors \n >");
                        
                        int optionMove = scan.nextInt();
                        Move playerMove = null;
                        
                        switch(optionMove) {
                            case 1: 
                                playerMove = rock;
                                break;
                                
                            case 2: 
                                playerMove = paper;
                                break;
                                
                            case 3: 
                                playerMove = scissors;
                                break;
                        }
                        
                        int random = (int) Math.floor(Math.random()*3) + 1;
                        Move computerMove = null;
                        
                        switch(random) {
                            case 1: 
                                computerMove = rock;
                                break;
                                
                            case 2: 
                                computerMove = paper;
                                break;
                                
                            case 3: 
                                computerMove = scissors;
                                break;
                        }
                        
                        int winner;
                        winner = Move.compareMoves(playerMove, computerMove);
                        
                        switch(winner) {
                            case 0:
                                System.out.println("\nPlayer chose " + playerMove.getName() + "."
                                + " Computer chose " + computerMove.getName() + "."
                                + " Player wins round!.");
                                playerScore++;
                                break;
                                
                            case 1:
                                System.out.println("\nPlayer chose " + playerMove.getName() + "."
                                + " Computer chose " + computerMove.getName() + "."
                                + " Computer wins round!.");
                                computerScore++;
                                break;
                                
                            case 2: 
                                System.out.println("\nPlayer chose " + playerMove.getName() + "."
                                + " Computer chose " + computerMove.getName() + "."
                                + " Round is tied!");
                                break;     
                        }
                        
                        System.out.println("Player: " + playerScore + " - "
                                + "Computer: " + computerScore);
                        
                        if(playerScore == roundsToWin) {
                            System.out.println("Player wins!");
                        }
                        else if (computerScore == roundsToWin){
                            System.out.println("Computer wins!");
                        } 
                    }
                    
                    donePlaying = false;
                    break;
                
                case 2: 
                    System.out.println("\n How many wins are needed to win a match? \n > ");
                 
                    roundsToWin = scan.nextInt();
                    System.out.println("\n New setting has been saved! You need to win " + roundsToWin + " matches.");
                    
                    break;
                    
                case 3: 
                    System.out.println("Thank you for playing!");

                    donePlaying = false;
                    break;
                    
                default: 
                    System.out.println("\nInvalid input. The program will now terminate.");
                    
                    donePlaying = false;
                    break; 
            }   
        }
    }
    
}
